import gymnasium as gym
import matplotlib
import matplotlib.pyplot as plt
from collections import deque
from itertools import count
import numpy as np

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F

from Omok4 import Omok
from rule import *

import pygame, sys
from pygame.locals import *

from agent import Agent

bg_color = (128, 128, 128)
black = (0, 0, 0)
blue = (0, 50, 255)
white = (255, 255, 255)
red = (255, 0, 0)
green = (0, 200, 0)

window_width = 800
window_height = 500
board_width = 500
grid_size = 30


# pygame.init()
# surface = pygame.display.set_mode((window_width, window_height))
# pygame.display.set_caption("Omok game")
# surface.fill(bg_color)
# black_img = pygame.image.load('omok/image/black.png')
# white_img = pygame.image.load('omok/image/white.png')
# blank_img = pygame.image.load('omok/image/blank.png')
# last_w_img = pygame.image.load('omok/image/white_a.png')
# last_b_img = pygame.image.load('omok/image/black_a.png')
# board_img = pygame.image.load('omok/image/board.png')
# black_img = pygame.transform.scale(black_img, (grid_size, grid_size))
# white_img = pygame.transform.scale(white_img, (grid_size, grid_size))

# def draw_board(observation):
#     surface.blit(board_img, (0,0))
#     x = 0
#     y = 0
#     for row in observation:
#         x = 0
#         for col in row:
#             if col == 1:
#                 surface.blit(black_img, ((x * grid_size) + 25 , (y * grid_size) + 25))
#             elif col == 2:
#                 surface.blit(white_img, ((x * grid_size) + 25, (y * grid_size) + 25))
#             x +=1
#         y +=1
#     pygame.display.update()
#     k = 5

# is_ipython = 'inline' in matplotlib.get_backend()
# if is_ipython:
#     from IPython import display

# # set up matplotlib
# episode_durations = []
# plt.ion()
# def plot_durations(show_result=False):
#     plt.figure(1)
#     durations_t = torch.tensor(episode_durations, dtype=torch.float)
#     if show_result:
#         plt.title('Result')
#     else:
#         plt.clf()
#         plt.title('Training...')
#     plt.xlabel('Episode')
#     plt.ylabel('Duration')
#     plt.plot(durations_t.numpy())
#     # Take 100 episode averages and plot them too
#     if len(durations_t) >= 100:
#         means = durations_t.unfold(0, 100, 1).mean(1).view(-1)
#         means = torch.cat((torch.zeros(99), means))
#         plt.plot(means.numpy())

#     plt.pause(0.001)  # pause a bit so that plots are updated
#     if is_ipython:
#         if not show_result:
#             display.display(plt.gcf())
#             display.clear_output(wait=True)
#         else:
#             display.display(plt.gcf())














env = Omok(10)

# 텐서 계산에 GPU사용하기위해 device에 gpu변수 세팅
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 액션수와 state 수 세팅
n_actions = len(env.get_env())
n_observations = len(env.get_env())

print(n_observations)

# 플레이어1,2 에이전트 생성
player1 = Agent(n_observations, n_actions, env, device, 1)

steps_done = 0

if torch.cuda.is_available():
    num_episodes = 1000000
else:
    num_episodes = 50

for i_episode in range(num_episodes):
    # Initialize the environment and get it's state
    env.reset()
    state = env.get_env()
    state = torch.tensor(state, dtype=torch.float32, device=device)
    state = state.unsqueeze(0)
    
    for t in count():
        #플레이어 1이 둠
        action = player1.policy_net.select_action(state.squeeze(0))
        observation, reward, terminated = env.step(action.item())
        reward = torch.tensor([reward], device=device)
        done = terminated 
        
        if terminated:
            next_state = None
        else:
            next_state = torch.tensor(observation, dtype=torch.float32, device=device).unsqueeze(0)
        
        player1.memory.push(state, action, next_state, reward)

        # Move to the next state
        state = next_state

        # Perform one step of the optimization (on the policy network)
        player1.optimize_model()

        # Soft update of the target network's weights
        # θ′ ← τ θ + (1 −τ )θ′
        target_net_state_dict = player1.target_net.state_dict()
        policy_net_state_dict = player1.policy_net.state_dict()
        for key in policy_net_state_dict:
            target_net_state_dict[key] = policy_net_state_dict[key]*(player1.policy_net.TAU) + target_net_state_dict[key]*(1-player1.policy_net.TAU)
        player1.target_net.load_state_dict(target_net_state_dict)

        if done:
            # episode_durations.append(t + 1)
            # plot_durations()
            break
        
print('Complete')
# plot_durations(show_result=True)
# plt.ioff()
# plt.show()
