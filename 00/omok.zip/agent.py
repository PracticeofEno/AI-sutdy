from collections import namedtuple
from dqn import DQN, ReplayMemory
import torch.optim as optim
import torch
import torch.nn as nn

class Agent:
    def __init__(self, n_observations, n_actions, env, device, number):
        self.policy_net = DQN(n_observations, n_actions, env).to(device)
        self.target_net = DQN(n_observations, n_actions, env).to(device)
        self.target_net.load_state_dict(self.policy_net.state_dict())
        self.device = device
        self.number = number
        self.optimizer = optim.AdamW(self.policy_net.parameters(), lr=self.policy_net.LR, amsgrad=True)
        self.memory = ReplayMemory(10000)
        
        self.Transition = namedtuple('Transition',
                        ('state', 'action', 'next_state', 'reward'))
        
    def compute_loss(model, states, actions, rewards, gamma):
        states = torch.FloatTensor(states)
        actions = torch.LongTensor(actions)
        rewards = torch.FloatTensor(rewards)
        
        probs = model(states)
        log_probs = torch.log(probs)
        
        T = len(rewards)
        loss = 0
        for t in range(T):
            G = sum([gamma**(k-t-1) * rewards[k] for k in range(t, T)])
            loss += -1 * (G * log_probs[t][actions[t]])
        return loss
    
    def optimize_model(self):
        if len(self.memory) < self.policy_net.BATCH_SIZE:
            return
        transitions = self.memory.sample(self.policy_net.BATCH_SIZE)
        # Transpose the batch (see https://stackoverflow.com/a/19343/3343043 for
        # # detailed explanation). This converts batch-array of Transitions
        # # to Transition of batch-arrays.
        batch = self.Transition(*zip(*transitions))
        
        # Compute a mask of non-final states and concatenate the batch elements
        # # (a final state would've been the one after which simulation ended)
        non_final_mask = torch.tensor(tuple(map(lambda s: s is not None,
                                          batch.next_state)), device=self.device, dtype=torch.bool)
        non_final_next_states = torch.cat([s for s in batch.next_state
                                                if s is not None])
        state_batch = torch.cat(batch.state)
        action_batch = torch.cat(batch.action)
        reward_batch = torch.cat(batch.reward)
        
        # Compute Q(s_t, a) - the model computes Q(s_t), then we select the columns of actions taken. 
        # These are the actions which would've been taken
        # for each batch state according to policy_net
        state_action_values = self.policy_net(state_batch).gather(1, action_batch)
        
        # Compute V(s_{t+1}) for all next states.
        # Expected values of actions for non_final_next_states are computed based
        # on the "older" target_net; selecting their best reward with max(1)[0].
        # This is merged based on the mask, such that we'll have either the expected
        # state value or 0 in case the state was final.
        next_state_values = torch.zeros(self.policy_net.BATCH_SIZE, device=self.device)
        with torch.no_grad():
            next_state_values[non_final_mask] = self.target_net(non_final_next_states).max(1)[0]
        # Compute the expected Q values
        expected_state_action_values = (next_state_values * self.policy_net.GAMMA) + reward_batch
        
        # Compute Huber loss
        criterion = nn.SmoothL1Loss()
        loss = criterion(state_action_values, expected_state_action_values.unsqueeze(1))
        print (f' {self.number} -> {loss}')
        
        # Optimize the model
        self.optimizer.zero_grad()
        loss.backward()
        # In-place gradient clipping
        torch.nn.utils.clip_grad_value_(self.policy_net.parameters(), 100)
        self.optimizer.step()