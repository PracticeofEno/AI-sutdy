from Omok4 import Omok
from rule import *

game = Omok(10)

game.print_board()
print(game.put_stone(0, 1, 1))
print(game.put_stone(0, 2, 1))
print(game.put_stone(0, 3, 1))
print(game.put_stone(0, 4, 1))
print(game.put_stone(0, 5, 1))